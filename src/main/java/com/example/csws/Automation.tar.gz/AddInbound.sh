#!/usr/bin/bash

AddInbound()
{
    # port=(7777 7777 7777)
    local LIST_HPORT=$1
    local LIST_CPORT=$2
    local newHport=$3
    local newCport=$4
    local containerName=$5
    local IpAddress=$6
    local storageSize=$7
    local os=$8 #(csws_ubuntu, csws_centos)

    # Split
    IFS=',' read -ra HOST_PORTS <<< "LIST_HPORT"
    IFS=',' read -ra CONTAINER_PORTS <<< "LIST_CPORT"

    if [ -z "${HOST_PORTS}" ]; then
        echo "Error: HOST_PORTS is empty"
        exit 1
    fi

    # 인수가 잘 들어왔는지 확인
    if [ $# -lt 8 ]; then
        echo "3" #인수가 부족합니다.
        exit 1
    fi

    docker stop $containerName
    docker commit $containerName $os$Hport # 새로운 이미지 이름(운영체제 + 열 포트 번호)

    docker run -it --privileged -d -p $newHport:$newCport \
        $(for i in "${!HOST_PORTS[@]}"; do echo "-p ${HOST_PORTS[$i]}:${CONTAINER_PORTS[$i]} "; done)\
        --name $containerName --storage-opt size=$storageSize $os$Hport /sbin/init

    sudo ufw allow from $IpAddress to any port $newHport proto tcp
    sudo ufw disable
    sudo ufw enable
}

AddInbound $1 $2 $3 $4 $5 $6 $7 $8 && echo "99"