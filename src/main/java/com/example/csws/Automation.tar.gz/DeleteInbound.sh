#!/usr/bin/bash

ClosePort()
{
    # port=(7777 7777 7777)
    local LIST_HPORT=$1
    local LIST_CPORT=$2
    # 스프링에서 삭제할 포트 데이터에서 삭제해서 호스트 포트 리스트로 줄 수 이산?
    local containerName=$3
    local IpAddress=$4
    local storageSize=$5
    local os=$6 #(csws_ubuntu, csws_centos)

    # 인수가 잘 들어왔는지 확인
    if [ $# -lt 6 ]; then
        echo "3" #인수가 부족합니다.
        exit 1
    fi

    docker stop $containerName
    docker commit $containerName $os$Hport # 새로운 이미지 이름(운영체제 + 열 포트 번호)

    docker run -it --privileged -d \
        $(for i in "${!HOST_PORTS[@]}"; do echo "-p ${HOST_PORTS[$i]}:${CONTAINER_PORTS[$i]} "; done)\
        --name $containerName --storage-opt size=$storageSize $os$Hport /sbin/init

    sudo ufw delete allow from $IpAddress to any port $newHport proto tcp
    sudo ufw disable
    sudo ufw enable
}

ClosePort $1 $2 $3 $4 $5 $6 && echo "99"